CREATE INDEX ID
ON SomeTable (SomeDate)

